package com.example.tourist_guide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
